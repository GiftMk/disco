"use strict";console.log("hello world");
//# sourceMappingURL=index.js.map
